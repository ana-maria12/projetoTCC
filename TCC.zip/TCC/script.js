
const loginForm = document.getElementById("login-form");
const scheduleForm = document.getElementById("schedule-form");
const scheduleTableBody = document.getElementById("schedule-table")?.getElementsByTagName("tbody")[0];
const viewSection = document.getElementById("view-section");
const scheduleSection = document.getElementById("schedule-section");
let currentUser  = null; // Iinicializa a variavel currentUser

async function authenticateUser (username, password) {
    const response = await fetch('http://localhost:3000/users');
    const users = await response.json();
    return users.find(u => u.username === username && u.password === password);
}

if (loginForm) {
    loginForm.addEventListener("submit", async (event) => {
        event.preventDefault();
        const username = document.getElementById("username").value;
        const password = document.getElementById("password").value;
        const user = await authenticateUser (username, password);

        if (user) {
            if (currentUser  !== username) { // Checa se o usuario é diferente
                currentUser  = username; // Seta o usuario atual
                document.getElementById("login-section").style.display = "none"; // Esconde a pagina de login
                document.getElementById("schedule-section").style.display = "block"; // Revela a pagina da tabela
                updateScheduleTable(); // Update the schedule table
            } else {
                alert("Você já está logado como " + currentUser ); // Informa que o usuario ja esta logado
            }
        } else {
            alert("Usuário ou senha incorretos."); // Mensagem de erro no caso de dados incorretos
        }
    });
}

async function loadSchedules() {
    const response = await fetch('http://localhost:3000/schedules');
    return await response.json();
}

async function saveSchedule(schedule) {
    await fetch('http://localhost:3000/schedules', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(schedule)
    });
}

async function deleteSchedule(id) {
    await fetch(`http://localhost:3000/schedules/${id}`, {
        method: 'DELETE'
    });
}

async function updateScheduleTable() {
    if (scheduleTableBody) {
        const schedules = await loadSchedules();
        scheduleTableBody.innerHTML = ""; // Limpa linhas existentes

        schedules.forEach((schedule) => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${schedule.room}</td>
                <td>${schedule.date}</td>
                <td>${schedule.time}</td>
                <td>${schedule.professor}</td>
                <td>${schedule.time2}</td>
                ${currentUser  === schedule.professor ? `<td><button class="delete-button" data-id="${schedule.id}">Excluir</button></td>` : ''}
            `;
            scheduleTableBody.appendChild(row);
        });

        // Adciona a funcionalidade de "delete" para cada botão de deletar
        document.querySelectorAll(".delete-button").forEach(button => {
            button.addEventListener("click", async (event) => {
                const id = event.target.getAttribute("data-id");
                await deleteSchedule(id);
                updateScheduleTable(); // Atualiza a tabela
            });
        });
    }
}
// Função para carregar agendamentos
async function loadSchedules() {
  const response = await fetch('http://localhost:3000/schedules');
  return await response.json();
}

// Função para salvar agendamento
async function saveSchedule(schedule) {
  await fetch('http://localhost:3000/schedules', {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json'
      },
      body: JSON.stringify(schedule)
  });
}

// Função para excluir agendamento
async function deleteSchedule(id) {
  await fetch(`http://localhost:3000/schedules/${id}`, {
      method: 'DELETE'
  });
}

// Função para atualizar tabela de agendamentos
async function updateScheduleTable() {
  if (scheduleTableBody) {
      const schedules = await loadSchedules();
      scheduleTableBody.innerHTML = ""; // Limpa a tabela antes de atualizar

      // Adiciona uma linha para cada agendamento
      schedules.forEach((schedule) => {
          const row = document.createElement("tr");
          row.innerHTML = `
              <td>${schedule.room}</td>
              <td>${schedule.date}</td>
              <td>${schedule.time}</td>
              <td>${schedule.professor}</td>
              <td>${schedule.time2}</td>
              ${currentUser  === schedule.professor ? `<td><button class="delete-button" data-id="${schedule.id}">Excluir</button></td>` : ''}
          `;
          scheduleTableBody.appendChild(row);
      });

      // Adiciona o evento de clique aos botões de exclusão
      document.querySelectorAll(".delete-button").forEach(button => {
          button.addEventListener("click", async (event) => {
              const id = event.target.getAttribute("data-id");
              await deleteSchedule(id);
              updateScheduleTable(); // Atualiza a tabela de agendamentos
          });
      });
  }
}

// Função para obter a data e hora atual em Brasília no formato YYYY-MM-DD HH:mm
function getCurrentDateInBrasilia() {
  const options = { timeZone: 'America/Sao_Paulo' };
  const now = new Date();
  
  // Obter a data e hora em Brasília
  const dateInBrasilia = new Date(now.toLocaleString('en-US', options));
  
  // Extrair ano, mês e dia
  const year = dateInBrasilia.getFullYear();
  const month = dateInBrasilia.getMonth() + 1 // Mês começa em 0
  const day = dateInBrasilia.getDate()
  
  // Extrair hora e minutos

  // Retorna no formato YYYY-MM-DD HH:mm
  return `${month}/${day}/${year}`;
}
function getCurrentTimeInBrasilia() {
  const options = { timeZone: 'America/Sao_Paulo' };
  const now = new Date();
  
  // Obter a data e hora em Brasília
  const dateInBrasilia = new Date(now.toLocaleString('en-US', options));
  
  // Extrair ano, mês e dia
  const year = dateInBrasilia.getFullYear();
  const month = String(dateInBrasilia.getMonth() + 1).padStart(2, '0'); // Mês começa em 0
  const day = String(dateInBrasilia.getDate()).padStart(2, '0');
  
  // Extrair hora e minutos
  const hours = String(dateInBrasilia.getHours()).padStart(2, '0');
  const minutes = String(dateInBrasilia.getMinutes()).padStart(2, '0');

  // Retorna no formato YYYY-MM-DD HH:mm
  return `${hours}:${minutes}`;
}

// Testando a função
console.log(getCurrentDateInBrasilia());

// Função para verificar e excluir reservas
async function checkAndDeleteExpiredSchedules() {
  const schedules = await loadSchedules();
  const currentTimeFormatted = getCurrentTimeInBrasilia(); // Obtém a data e hora atuais
  const currentDateFormatted = getCurrentDateInBrasilia(); // Obtém a data e hora atuais

// Cria um objeto Date a partir da string formatada
//const currentDateTime = new Date(currentTimeFormatted.replace(' ', 'T')); // Converte para formato ISO

schedules.forEach(async (schedule) => {
    // Verifica se a data e hora estão definidas
    if (!schedule.date || !schedule.time2) {
        console.error(`Data ou hora não definida para a reserva ID: ${schedule.id}`);
        return; // Pula para a próxima iteração
    }

// Converte a data de DD/MM/YYYY para YYYY-MM-DD
      const [day, month, year] = schedule.date.split('/');
      const formattedDate = `${year}-${month}-${day}`; // Formato YYYY-MM-DD

      // Converte a hora de HH:mm
      const [hour, minute] = schedule.time2.split(':');

      // Cria uma string no formato YYYY-MM-DD HH:mm
      const scheduleDate = `${year}-${month}-${day}`;
      const scheduleTimeFormatted = `${hour}:${minute}`;

      const scheduleDateFormatted = new Date(formattedDate).toLocaleDateString(
        'en-US',
      {
        day: 'numeric',
        month: 'numeric',
        year: 'numeric',
        timeZone: 'America/Sao_Paulo'
      })

      console.log(scheduleDateFormatted)

      // Log para depuração
      console.log(`Comparando: ${scheduleTimeFormatted} com ${currentTimeFormatted} e ${scheduleDateFormatted} com ${currentDateFormatted}`);
      
      // Verifica se a data e hora da reserva são iguais ou anteriores à data e hora atuais
      if (scheduleTimeFormatted <= currentTimeFormatted &&
        currentDateFormatted == scheduleDateFormatted) { // Use <= para excluir no mesmo instante ou já passado
         console.log(`Excluindo reserva: ${schedule.id}`)
         await deleteSchedule(schedule.id); // Exclui a reserva
         updateScheduleTable(); // Atualiza a tabela de agendamentos
     }else if(currentDateFormatted > scheduleDateFormatted){
      console.log('data menor!')
      // console.log(`Excluindo reserva: ${schedule.id}`)
      // await deleteSchedule(schedule.id); // Exclui a reserva
      // updateScheduleTable(); // Atualiza a tabela de agendamentos
      
     }else{
      console.log('data maior/igual')
     }
  });
}

// Chama a função de verificação a cada minuto
setInterval(checkAndDeleteExpiredSchedules, 10000); // 60000 ms = 1 minuto

if (scheduleForm) {
    scheduleForm.addEventListener("submit", async (event) => {
        event.preventDefault(); // Previnir o uso do processo padrão

        const room = document.getElementById("room").value;
        const date = document.getElementById("date").value;
        const time = document.getElementById("time").value;
        const time2 = document.getElementById("time2").value;

        if (currentUser ) {
            const schedules = await loadSchedules(); // Carregar schedules
            const isConflicted = schedules.some(schedule => 
                schedule.room === room && 
                schedule.date === date && 
                schedule.time === time &&
                schedule.time2 === time2
            );

            if (isConflicted) {
                alert("Conflito de agendamento: essa sala já está reservada para a data e hora selecionadas.");
            } else {
                const schedule = { room, date, time, professor: currentUser, time2  }; // Criar um novo objeto schedule
                await saveSchedule(schedule); // Salvar esse objeto
                updateScheduleTable(); // Atualiza a tabela
                
                scheduleForm.reset(); // Limpar os campos
            }
        }
    });
}



//ESTUDANTE ***********
async function fetchSchedules() {
    try {
        const response = await fetch('http://localhost:3000/schedules'); // Fetch 
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const schedules = await response.json(); // Parse JSON data
        populateScheduleTable(schedules); // Popular a tabela com os schedules
    } catch (error) {
        console.error('Error fetching schedules:', error);
    }
}

function populateScheduleTable(schedules) {
    const scheduleTableBody = document.getElementById("schedule-table").getElementsByTagName("tbody")[0];
    scheduleTableBody.innerHTML = ""; // Limpar as linhas da tabela

    schedules.forEach((schedule) => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${schedule.room}</td>
            <td>${schedule.date}</td>
            <td>${schedule.time}</td>
            <td>${schedule.professor}</td>
        `;
        scheduleTableBody.appendChild(row); // Adcionar uma nova linha a tabela
    });
}

// Chama a função de fetch quando a tabela carrega
document.addEventListener("DOMContentLoaded", fetchSchedules);



//Função ADM *********** 
document.addEventListener("DOMContentLoaded", () => {
    // Obtém referências aos elementos do DOM
    const loginForm = document.getElementById("adm-login-form");
    const scheduleForm = document.getElementById("schedule-form");
    const scheduleTableBody = document.getElementById("schedule-table")?.getElementsByTagName("tbody")[0];
    const viewSection = document.getElementById("view-section1");
    const scheduleSection = document.getElementById("schedule-section");
    const undoButton = document.getElementById("undo-button"); // Botão de desfazer
    
    // Armazena o usuário atualmente logado
    let currentUser  = null;
    // Armazena o último agendamento excluído
    let lastDeletedSchedule = null;
    // Armazena o índice do último agendamento excluído
    let lastDeletedIndex = null;

    async function authenticateUser (username, password) {
        const response = await fetch('http://localhost:3000/adm');
        const adms = await response.json();
        return adms.find(u => u.username === username && u.password === password);
    }
  
    if (loginForm) {
        loginForm.addEventListener("submit", async (event) => {
            event.preventDefault();
            const username = document.getElementById("username").value;
            const password = document.getElementById("password").value;
            const user = await authenticateUser (username, password);
    
            if (user) {
                if (currentUser  !== username) { // Checa se o usuário é diferente
                    currentUser  = username; // Seta o usuario atual
                    document.getElementById("login-section").style.display = "none"; // Esconde a pagima de login
                    document.getElementById("schedule-section").style.display = "block"; // Mostra a tabela
                    updateScheduleTable(); // Atualiza a tabela

                    alert("Você já está logado como " + currentUser ); // Informa se o usuario ja esta logado
                }
            } else {
                alert("Usuário ou senha incorretos."); // Mensagem de erro no caso de informações incorretas
            }
        });
    }
  
    // Função para carregar agendamentos
    async function loadSchedules() {
      const response = await fetch('http://localhost:3000/schedules');
      return await response.json();
    }
  
    // Função para salvar agendamento
    async function saveSchedule(schedule) {
      await fetch('http://localhost:3000/schedules', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(schedule)
      });
    }
  
    // Função para excluir agendamento
    async function deleteSchedule(id) {
      await fetch(`http://localhost:3000/schedules/${id}`, {
        method: 'DELETE'
      });
    }
  
    // Função para atualizar tabela de agendamentos
    async function updateScheduleTable() {
      if (scheduleTableBody) {
        const schedules = await loadSchedules();
        scheduleTableBody.innerHTML = ""; // Limpa a tabela antes de atualizar
  
        // Adiciona uma linha para cada agendamento
        schedules.forEach((schedule) => {
          const row = document.createElement("tr");
          row.innerHTML = `
            <td>${schedule.room}</td>
            <td>${schedule.date}</td>
            <td>${schedule.time}</td>
            <td>${schedule.professor}</td>
            <td>${schedule.time2}</td>
            ${currentUser  === schedule.professor || currentUser  === 'admin4' ? `<td><button class="delete-button" data-id="${schedule.id}">Excluir</button></td>` : ''}
          `;
          scheduleTableBody.appendChild(row);
        });
  
        // Adiciona o evento de clique aos botões de exclusão
        document.querySelectorAll(".delete-button").forEach(button => {
          button.addEventListener("click", async (event) => {
            const id = event.target.getAttribute("data-id");
            await deleteSchedule(id);
            updateScheduleTable(); // Atualiza a tabela de agendamentos
          });
        });
      }
    }
  
    // Evento de submit para o formulário de login
    if (loginForm) {
      loginForm.addEventListener("submit", async (event) => {
        event.preventDefault(); // Impede o comportamento padrão de envio do formulário
  
        const username = document.getElementById("username").value;
        const password = document.getElementById("password").value;
        const user = await authenticateUser (username, password);
        const admin = await authenticateAdmin(username, password);
  
        if (user || admin) {
          currentUser  = user ? user.username : admin.username; // Define o usuário logado
          document.getElementById("login-section").style.display = "none"; // Oculta a seção de login
          document.getElementById("view-section1").style.display = "block";
          document.getElementById("schedule-section").style.display = "block"; // Exibe a seção de agendamento
          updateScheduleTable(); // Atualiza a tabela de agendamentos
        } else {
          alert("Usuário ou senha incorretos."); // Exibe mensagem de erro se as credenciais estiverem erradas
        }
      });
    }
  
    // Evento de submit para o formulário de agendamento
    if (scheduleForm) {
      scheduleForm.addEventListener("submit", async (event ) => {
        event.preventDefault(); // Impede o comportamento padrão de envio do formulário
  
        const room = document.getElementById("room").value;
        const date = document.getElementById("date").value;
        const time = document.getElementById("time").value;
        const time2 = document.getElementById("time2").value;
  
        if (currentUser) {
          const schedules = await loadSchedules(); // Carrega agendamentos existentes
          const isConflicted = schedules.some(schedule =>
            schedule.room === room &&
            schedule.date === date &&
            schedule.time === time &&
            schedule.time2 === time2
          );
  
          if (isConflicted) {
            alert("Conflito de agendamento: essa sala já está reservada para a data e hora selecionadas.");
          } else {
            const schedule = { room, date, time, professor: currentUser }; // Cria um novo agendamento
            await saveSchedule(schedule); // Salva o novo agendamento
            updateScheduleTable(); // Atualiza a tabela de agendamentos
            // Opcionalmente, você pode limpar os campos do formulário após a submissão
            scheduleForm.reset(); // Limpa campos do formulário
          }
        }
      });
    }
  
    // Função para desfazer exclusão
    async function undoDelete() {
      if (lastDeletedSchedule !== null && lastDeletedIndex !== null) {
        const schedules = await loadSchedules();
        schedules.splice(lastDeletedIndex, 0, lastDeletedSchedule); // Reinsere o agendamento no array
        await saveSchedule(lastDeletedSchedule);
        updateScheduleTable();
  
        lastDeletedSchedule = null; // Limpa o agendamento excluído
        lastDeletedIndex = null; // Limpa o índice do agendamento excluído
  
        // Oculta o botão de desfazer
        if (undoButton) {
          undoButton.style.display = "none";
        }
      }
    }
  
    // Evento de clique para o botão de desfazer
    if (undoButton) {
      undoButton.addEventListener("click", undoDelete);
      undoButton.style.display = "none"; // Inicialmente oculta o botão de desfazer
    }
  
    // Atualiza a tabela de agendamentos ao carregar a página
    updateScheduleTable();
  });


  document.getElementById('schedule-form').addEventListener('submit', function(event) {
            event.preventDefault(); // Previne o comportamento padrão de envio do formulário
            alert('Reserva feita'); // Exibe o alert
            // Aqui você pode adicionar o código para processar a reserva, como adicionar à tabela.
        });
